%%%%%demo
load('../models/recorded_motions/nao_3','demos');
N=size(demos{1},2);
angles=zeros(4,N);
for i=2:N
    angles(:,i)=leftArm(demos{1}(:,i),angles(:,i-1));
end