function out = Mat_Vec_Norm( x )

out = sqrt(sum(x.^2,1));

end

