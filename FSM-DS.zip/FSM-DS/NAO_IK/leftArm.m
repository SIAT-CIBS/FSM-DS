function [angles, accuracy]=leftArm(targetV,X0)
%f(x1,x2,x3)=[1,0,0;0,cos(x1),sin(x1);0, -sin(x1),cos(x1)]*...
%    [cos(x2),-sin(x2),0;sin(x2),cos(x2),0;0,0,1]*[0;105;0]+...
%    [1,0,0;0,cos(x1),sin(x1);0, -sin(x1),cos(x1)]*...
%    [cos(x2),-sin(x2),0;sin(x2),cos(x2),0;0,0,1]*...
%    [cos(x3),0,sin(x3);0,1,0;-sin(x3),0,cos(x3)]*...
%    [cos(theta),-sin(theta),0;sin(theta),cos(theta),0;0,0,1]*[0;113.7;0];
%Solve the inverse kinematic problem with angle in radious
l=[105;113.7];
if norm(targetV)>sum(l)
    error(['Hand length is restricted in '  num2str(sum(l))]);
end

theta=pi-acos((l(1)*l(1)+l(2)*l(2)-targetV'*targetV)/(2*l(1)*l(2)));
theta=-theta;
X0=[X0(1),X0(2),X0(3)];

options.max_iter=1000;
options.tol_stopping=10^-10;
[targetX,accuracy]=IK(theta,targetV,X0,options);
angles=[targetX(1);targetX(2);targetX(3);theta];