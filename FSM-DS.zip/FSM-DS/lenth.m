function len = lenth(x,y)
len = sqrt((x(1)-y(1))^2+(x(2)-y(2))^2);