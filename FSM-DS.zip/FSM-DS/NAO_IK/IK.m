function [targetX,accuracy]=IK(theta,targetVec,X0,options)
if ~isfield(options,'max_iter') % maximum number of iterations
    options.max_iter=1000;
end
if ~isfield(options,'tol_stopping') % maximum number of iterations
    options.tol_stopping=10^-10;
end

D2R=57.29578;
min_angle=[-119.5;0.5;-119.5];
max_angle=[119.5;94.5;119.5];
min_angle=min_angle/D2R;
max_angle=max_angle/D2R;
obj_handle = @(x) obj(targetVec,x,theta);
optNLP = optimset( 'Algorithm', 'interior-point', 'LargeScale', 'off',...
        'GradObj', 'on',  'DerivativeCheck', 'off', ...
        'Display', 'iter', 'TolX', 1e-12, 'TolFun', 1e-12, 'TolCon', 1e-12, ...
        'MaxFunEval', 200000, 'MaxIter', options.max_iter, 'DiffMinChange', ...
         options.tol_stopping, 'Hessian','off','display','iter');
targetX = fminunc(obj_handle, X0,optNLP);
%targetX=fmincon(obj_handle,X0,[],[],[],[],min_angle,max_angle,[],optNLP);

accuracy=obj(targetVec,targetX,theta);


function [val,dJ]=obj(targetVec,X0,theta)
y=leftArmVec(theta,X0);
val=(y-targetVec)'*(y-targetVec);
dJ=(y-targetVec)'*leftArmVecDiff(theta,X0);
dJ=dJ';


function y=leftArmVec(theta,X0)
x1=X0(1);
x2=X0(2);
x3=X0(3);
y1= - 105*sin(x2) - (1137*cos(theta)*sin(x2))/10 - (1137*cos(x2)*cos(x3)*sin(theta))/10;
y2=105*cos(x1)*cos(x2) + (1137*sin(theta)*(sin(x1)*sin(x3) - cos(x1)*cos(x3)*sin(x2)))/10 + (1137*cos(theta)*cos(x1)*cos(x2))/10;
y3=(1137*sin(theta)*(cos(x1)*sin(x3) + cos(x3)*sin(x1)*sin(x2)))/10 - 105*cos(x2)*sin(x1) - (1137*cos(theta)*cos(x2)*sin(x1))/10;
y=[y1;y2;y3];

function dY=leftArmVecDiff(theta,X0)
x1=X0(1);
x2=X0(2);
x3=X0(3);
diff_x1=[0;...
    (1137*sin(theta)*(cos(x1)*sin(x3) + cos(x3)*sin(x1)*sin(x2)))/10 - 105*cos(x2)*sin(x1) - (1137*cos(theta)*cos(x2)*sin(x1))/10;...
    - 105*cos(x1)*cos(x2) - (1137*sin(theta)*(sin(x1)*sin(x3) - cos(x1)*cos(x3)*sin(x2)))/10 - (1137*cos(theta)*cos(x1)*cos(x2))/10];
diff_x2=[  (1137*cos(x3)*sin(theta)*sin(x2))/10 - (1137*cos(theta)*cos(x2))/10 - 105*cos(x2);...
      - 105*cos(x1)*sin(x2) - (1137*cos(theta)*cos(x1)*sin(x2))/10 - (1137*cos(x1)*cos(x2)*cos(x3)*sin(theta))/10;...
      105*sin(x1)*sin(x2) + (1137*cos(theta)*sin(x1)*sin(x2))/10 + (1137*cos(x2)*cos(x3)*sin(theta)*sin(x1))/10];
 diff_x3=[  (1137*cos(x2)*sin(theta)*sin(x3))/10;...
      (1137*sin(theta)*(cos(x3)*sin(x1) + cos(x1)*sin(x2)*sin(x3)))/10;...
     (1137*sin(theta)*(cos(x1)*cos(x3) - sin(x1)*sin(x2)*sin(x3)))/10];
dY=[diff_x1,diff_x2,diff_x3];